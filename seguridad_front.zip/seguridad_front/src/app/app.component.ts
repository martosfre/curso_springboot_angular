import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { FormsModule} from "@angular/forms";

@Component({
  selector: 'app-root', //Conmo se va a llamar al componente
  standalone: true,
  imports: [CommonModule, RouterOutlet, FormsModule],
  templateUrl: './app.component.html', //Cúal es la página web o cual es contenido html (vista)
  styleUrl: './app.component.css' //Hoja(s) de estilo
})
export class AppComponent {
  title = 'Seguridades FFTT';
  nombre = "Matoosfes ";
  isDisabled = false;
}
