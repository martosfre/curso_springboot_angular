import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
@NgModule({
  /*
     Declaramos todos los componentes , directivas y pipes que forman parte del módulo, los componentes
     se deben declarar en un solo módulo
   */
  declarations: [],
  imports: [ // Declaramos todos los módulos que se van a utilizar en los componentes
    CommonModule
  ],
  providers: [],
  exports: [],
  bootstrap:[],
  entryComponents: [],
})
export class AdminModule { }
